<?php
/**
 * @package     electromonitor.com
 * @subpackage  mod_meter_model_fix
 *
 * @copyright   Copyright (C) 2015 All rights reserved.
 */

defined('_JEXEC') or die;
?>

<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
</head>


<div id="electrical">
    <br><br>
<form id=form  name="form"  method="post" action="index.php/meter-model-update" onSubmit='return javacheck(this)'>
 <table width="900px" align=left  cellpadding="0" cellspacing="0" style="background-color:#F8F8FF;border-left:none;border-top:none;border-right:none;"> 
   <tr > 
    <td border="0" cellpadding="0" cellspacing="0" style="padding-left:5px;">
           <font style="color:#00a0e8">序&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;号：&nbsp;&nbsp;<?php echo $meter_model_id; ?></font>
		   <input id="meter_model_id" name="meter_model_id" type="hidden" size="10" value="<?php echo $meter_model_id; ?>" />
		   <br><br>
            	
           电表型号：&nbsp;
        <input id="meter_model" name="meter_model" type="text" size="10" value="<?php echo $meter_model; ?>" /><br>
           生产厂名：&nbsp;
        <input id="meter_factory" name="meter_factory" type="text" size="10" value="<?php echo $meter_factory; ?>" /><br>
           指&nbsp;令&nbsp;码A：
        <input id="command_code" name="command_code" type="text" size="10" value="<?php echo $command_code; ?>" /><br>
		   指&nbsp;令&nbsp;码B：
        <input id="command_code2" name="command_code2" type="text" size="10" value="<?php echo $command_code2; ?>" /><br>
           长&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;度：
        <input id="var_len" name="var_len" type="text" size="10" value="<?php echo $var_len; ?>" /><br>
           功&nbsp;&nbsp;能&nbsp;&nbsp;码：
        <input id="function_code" name="function_code" type="text" size="10" value="<?php echo $function_code; ?>" /><br>
           起始寄存器地址：
        <input id="storage_start_address" name="storage_start_address" type="text" size="10" value="<?php echo $storage_start_address; ?>" /><br>
           寄存器长度：
        <input id="storage_numbers" name="storage_numbers" type="text" size="10" value="<?php echo $storage_numbers; ?>" /><br>
		   参数位置：&nbsp;
        <textarea class="input-xxlarge" id="data_index" name="data_index" type="text"  value="<?php echo $data_index; ?>" /><?php echo $data_index; ?></textarea><br>
          <font style="color:#5d5d5d;"> 
		   *参数位置的填写模式为：项目名:始位置-终位置<br>
			例： Ua:7-8, Ub:9-10, Uc:11-12, U_ab:13-14, U_bc:15-16, U_ca:17-18, Ia:19-20, Ib:21-22, Ic:23-24, Pa:25-26, Pb:27-28, Pc:29-30, Ps:31-32, FR:57-58, Qa:33-34, Qb:35-36, Qc:37-38, Qs:39-40, PFa:41-42, PFb:43-44, PFc:45-46, PFs:47-48, Sa:49-50, Sb:51-52, Sc:53-54, Ss:55-56, WPP:59-62, WPN:63-66, WQP:67-70, WQN:71-74, EPP:75-78, EPN:79-82, EQP:83-86,EQN:87-88 
		  </font>
		<br><br>
		
		
		参数项取值设置：
		<table width="900px" align="left"  border="1px">
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">Ua：</td>
		    <td style="padding-left:10px;"><input name="Ua_hexTodec" type="checkbox"  value="<?php if($Ua_hexTodec == "1"){echo $meter_model; ?>" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="Ua_Float" type="checkbox"  value="<?php echo $meter_model; ?>" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="Ua_formatNum" type="text"  class="input-small" value="<?php echo $meter_model; ?>" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="Ua_formula" type="text"  value="<?php echo $meter_model; ?>" /></td>
			</td>			
		 </tr>
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">Ub：</td>
		    <td style="padding-left:10px;"><input name="Ub_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="Ub_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="Ub_formatNum" type="text" class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="Ub_formula" type="text" value="" /></td>
			</td>			
		 </tr>
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">Uc：</td>
		    <td style="padding-left:10px;"><input name="Uc_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="Uc_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="Uc_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="Uc_formula" type="text"  value="" /></td>
			</td>			
		 </tr>
		 
		 
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">U_ab：</td>
		    <td style="padding-left:10px;"><input name="U_ab_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="U_ab_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="U_ab_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="U_ab_formula" type="text"  value="" /></td>
			</td>			
		 </tr>
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">U_bc：</td>
		    <td style="padding-left:10px;"><input name="U_bc_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="U_bc_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="U_bc_formatNum" type="text" class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="U_bc_formula" type="text" value="" /></td>
			</td>			
		 </tr>
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">U_ca：</td>
		    <td style="padding-left:10px;"><input name="U_ca_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="U_ca_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="U_ca_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="U_ca_formula" type="text"  value="" /></td>
			</td>			
		 </tr>
		 
		 
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">Ia：</td>
		    <td style="padding-left:10px;"><input name="Ia_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="Ia_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="Ia_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="Ia_formula" type="text"  value="" /></td>
			</td>			
		 </tr>
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">Ib：</td>
		    <td style="padding-left:10px;"><input name="Ib_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="Ib_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="Ib_formatNum" type="text" class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="Ib_formula" type="text" value="" /></td>
			</td>			
		 </tr>
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">Ic：</td>
		    <td style="padding-left:10px;"><input name="Ic_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="Ic_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="Ic_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="Ic_formula" type="text"  value="" /></td>
			</td>			
		 </tr>
		 
		 
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">Pa：</td>
		    <td style="padding-left:10px;"><input name="Pa_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="Pa_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="Pa_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="Pa_formula" type="text"  value="" /></td>
			</td>			
		 </tr>
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">Pb：</td>
		    <td style="padding-left:10px;"><input name="Pb_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="Pb_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="Pb_formatNum" type="text" class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="Pb_formula" type="text" value="" /></td>
			</td>			
		 </tr>
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">Pc：</td>
		    <td style="padding-left:10px;"><input name="Pc_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="Pc_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="Pc_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="Pc_formula" type="text"  value="" /></td>
			</td>			
		 </tr>
         <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">Ps：</td>
		    <td style="padding-left:10px;"><input name="Ps_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="Ps_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="Ps_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="Ps_formula" type="text"  value="" /></td>
			</td>			
		 </tr> 		 
		 
		 
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">Pa：</td>
		    <td style="padding-left:10px;"><input name="Pa_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="Pa_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="Pa_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="Pa_formula" type="text"  value="" /></td>
			</td>			
		 </tr>
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">Pb：</td>
		    <td style="padding-left:10px;"><input name="Pb_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="Pb_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="Pb_formatNum" type="text" class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="Pb_formula" type="text" value="" /></td>
			</td>			
		 </tr>
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">Pc：</td>
		    <td style="padding-left:10px;"><input name="Pc_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="Pc_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="Pc_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="Pc_formula" type="text"  value="" /></td>
			</td>			
		 </tr>
         <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">Ps：</td>
		    <td style="padding-left:10px;"><input name="Ps_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="Ps_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="Ps_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="Ps_formula" type="text"  value="" /></td>
			</td>			
		 </tr>

        
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">FR：</td>
		    <td style="padding-left:10px;"><input name="FR_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="FR_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="FR_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="FR_formula" type="text"  value="" /></td>
			</td>			
		 </tr> 

		 
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">Qa：</td>
		    <td style="padding-left:10px;"><input name="Qa_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="Qa_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="Qa_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="Qa_formula" type="text"  value="" /></td>
			</td>			
		 </tr>
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">Qb：</td>
		    <td style="padding-left:10px;"><input name="Qb_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="Qb_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="Qb_formatNum" type="text" class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="Qb_formula" type="text" value="" /></td>
			</td>			
		 </tr>
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">Qc：</td>
		    <td style="padding-left:10px;"><input name="Qc_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="Qc_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="Qc_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="Qc_formula" type="text"  value="" /></td>
			</td>			
		 </tr>
         <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">Qs：</td>
		    <td style="padding-left:10px;"><input name="Qs_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="Qs_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="Qs_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="Qs_formula" type="text"  value="" /></td>
			</td>			
		 </tr>
		 
		 
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">PFa：</td>
		    <td style="padding-left:10px;"><input name="PFa_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="PFa_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="PFa_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="PFa_formula" type="text"  value="" /></td>
			</td>			
		 </tr>
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">PFb：</td>
		    <td style="padding-left:10px;"><input name="PFb_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="PFb_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="PFb_formatNum" type="text" class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="PFb_formula" type="text" value="" /></td>
			</td>			
		 </tr>
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">PFc：</td>
		    <td style="padding-left:10px;"><input name="PFc_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="PFc_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="PFc_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="PFc_formula" type="text"  value="" /></td>
			</td>			
		 </tr>
         <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">PFs：</td>
		    <td style="padding-left:10px;"><input name="PFs_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="PFs_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="PFs_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="PFs_formula" type="text"  value="" /></td>
			</td>			
		 </tr>
		 
		 
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">Sa：</td>
		    <td style="padding-left:10px;"><input name="Sa_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="Sa_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="Sa_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="Sa_formula" type="text"  value="" /></td>
			</td>			
		 </tr>
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">Sb：</td>
		    <td style="padding-left:10px;"><input name="Sb_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="Sb_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="Sb_formatNum" type="text" class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="Sb_formula" type="text" value="" /></td>
			</td>			
		 </tr>
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">Sc：</td>
		    <td style="padding-left:10px;"><input name="Sc_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="Sc_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="Sc_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="Sc_formula" type="text"  value="" /></td>
			</td>			
		 </tr>
         <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">Ss：</td>
		    <td style="padding-left:10px;"><input name="Ss_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="Ss_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="Ss_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="Ss_formula" type="text"  value="" /></td>
			</td>			
		 </tr>
		 
		 
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">WPP：</td>
		    <td style="padding-left:10px;"><input name="WPP_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="WPP_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="WPP_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="WPP_formula" type="text"  value="" /></td>
			</td>			
		 </tr>
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">WPN：</td>
		    <td style="padding-left:10px;"><input name="WPN_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="WPN_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="WPN_formatNum" type="text" class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="WPN_formula" type="text" value="" /></td>
			</td>			
		 </tr>
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">WQP：</td>
		    <td style="padding-left:10px;"><input name="WQP_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="WQP_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="WQP_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="WQP_formula" type="text"  value="" /></td>
			</td>			
		 </tr>
         <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">WQN：</td>
		    <td style="padding-left:10px;"><input name="WQN_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="WQN_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="WQN_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="WQN_formula" type="text"  value="" /></td>
			</td>			
		 </tr>
		 
		 
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">EPP：</td>
		    <td style="padding-left:10px;"><input name="EPP_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="EPP_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="EPP_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="EPP_formula" type="text"  value="" /></td>
			</td>			
		 </tr>
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">EPN：</td>
		    <td style="padding-left:10px;"><input name="EPN_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="EPN_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="EPN_formatNum" type="text" class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="EPN_formula" type="text" value="" /></td>
			</td>			
		 </tr>
		 <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">EQP：</td>
		    <td style="padding-left:10px;"><input name="EQP_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="EQP_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="EQP_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="EQP_formula" type="text"  value="" /></td>
			</td>			
		 </tr>
         <tr align="left" onmouseover="this.style.backgroundColor='#e5ff00'" onmouseout="this.style.backgroundColor='#ffffff'">
            <td style="padding-left:10px;">EQN：</td>
		    <td style="padding-left:10px;"><input name="EQN_hexTodec" type="checkbox"  value="" />16进制转10进制</td>
		    <td style="padding-left:10px;"><input name="EQN_Float" type="checkbox"  value="" />浮点型转换</td>
			<td style="padding-left:10px;">截取小数位个数：<input name="EQN_formatNum" type="text"  class="input-small" value="" /></td>
			<td style="padding-left:10px;">代入公式：      <input name="EQN_formula" type="text"  value="" /></td>
			</td>			
		 </tr>
		 
        </table>		 
       
    
	<table width="900px" align="left" >
	 <tr align="left">
	  <td><br>
	    <input type="submit" value=" 提  交 "  id="send-btn" />
		<br><br>
	  </td>
	 </tr>
	</table>
    </td>
   </tr>
 </table>
</form>



<script language=JavaScript1.2>
 
function javacheck(formct)
{
	
      
        
        if (formct.meter_model.value.replace(/^\s|\s$/g,'') == '') 
	{
		alert('请填写电表型号！');
                 formct.meter_model.focus();
		return false; 
	} 
	
	    if (formct.command_code.value.replace(/^\s|\s$/g,'') == '') 
	{
		alert('请填写指令码A！');
                 formct.command_code.focus();
		return false; 
	}
	
	    if (formct.command_code2.value.replace(/^\s|\s$/g,'') == '') 
	{
		alert('请填写指令码B!');
                 formct.command_code2.focus();
		return false; 
	}

    
       
}

</script>
          
   
</div>
