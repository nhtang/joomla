﻿<?php
/**
 * @package     electromonitor.com
 * @subpackage  mod_meter_model
 *
 * @copyright   Copyright (C) 2015 All rights reserved.
 */


defined('_JEXEC') or die;

// Include the functions only once
//require_once __DIR__ . '/helper.php';

JHTML::stylesheet('book.css','modules/mod_meter_model/css/');

require_once __DIR__ . '/conn.php';




//$lines = file("http://127.0.0.1/joomla/index.php/meter-model");

require(JModuleHelper::getLayoutPath('mod_meter_model', 'default'));
?>


 

