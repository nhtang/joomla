﻿<?php 
/**
 * @package     electromonitor.com
 * @subpackage  mod_meter_model_submit
 *
 * @copyright   Copyright (C) 2015 All rights reserved.
 */
 
 //header('Content-type:text/html;charset=utf8');

defined('_JEXEC') or die;

// Include the functions only once
//require_once __DIR__ . '/helper.php';
require_once __DIR__ . '/conn.php';

@$meter_model = trim($_POST['meter_model']); 

if($meter_model==""){
         mysql_close();
         echo "<script>alert('请先填写电表型号表格，然后按提交按钮提交数据！');history.back(); </script>";
}else{
	   
$meter_factory = trim($_POST['meter_factory']);
$command_code =trim($_POST['command_code']);
$var_len = trim($_POST['var_len']);
$address_code =trim($_POST['address_code']);
$function_code = trim($_POST["function_code"]);
$storage_start_address =trim($_POST['storage_start_address']); 
$storage_numbers =trim($_POST['storage_numbers']);
$check_code = trim($_POST['check_code']);

date_default_timezone_set('Asia/Singapore');
$datetime = date('Y-m-d H:i:s');
$datetime_create = $datetime;


// insert to database
//ModMeterModelSubmitHelper::insertMetermodelValues($datetime_create, $meter_model, $meter_factory $command_code, $var_len, $address_code, $function_code, $storage_start_address, $storage_numbers, $check_code);

    //$sq = "select command_code from joomla3_metermodel where command_code =".$command_code." order by id desc";
	$sq = "select meter_model_id, meter_model, meter_factory, command_code from joomla3_metermodel where command_code = '$command_code' ";
	   $rst = mysql_query($sq);
	   //$rsnum = mysql_num_rows($rst);
       $row = mysql_fetch_array($rst);
	   
    if($row != ""){
      mysql_close();
  
      echo " <script>alert('数据库中已存在相同的指令码！');history.back(); </script>";
  
    }else{
       $sql = "insert into joomla3_metermodel 
	     (meter_model, meter_factory, command_code, var_len, address_code, function_code, storage_start_address, storage_numbers, check_code, datetime_create)
	   values 
	     ('$meter_model', '$meter_factory', '$command_code', '$var_len', '$address_code', '$function_code', '$storage_start_address', '$storage_numbers','$check_code', '$datetime_create')";
	   
	   $result = mysql_query($sql);
	   
	   if($result==false){
         mysql_close();
         echo "<script>alert('写入数据表时出错！');history.back(); </script>";
       }else{
        
	       mysql_close();
           echo "<script>alert('录入成功！');history.back(); </script>";

       } 
	   
	}  
	   
	   
	require(JModuleHelper::getLayoutPath('mod_meter_model_submit', 'default'));
	
}
?>