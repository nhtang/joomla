﻿<?php 
/**
 * @package     electromonitor.com
 * @subpackage  mod_meter_model_submit
 *
 * @copyright   Copyright (C) 2015 All rights reserved.
 */
 
 //header('Content-type:text/html;charset=utf8');

defined('_JEXEC') or die;

// Include the functions only once
//require_once __DIR__ . '/helper.php';
require_once __DIR__ . '/conn.php';

echo "vvvvvvvvvvvvvvvvvv";

$meter_model =  JRequest::getVar( 'meter_model' ,  '-1');
$meter_model =  JRequest::getVar( 'meter_model' , '-1');
$meter_factory =  JRequest::getVar( 'meter_factory' , '-1');
$command_code =  JRequest::getVar( 'command_code' , '-1');
$var_len =  JRequest::getVar( 'var_len' , 'var_len' , '-1');
$address_code =  JRequest::getVar( 'address_code' , '-1');
$function_code =  JRequest::getVar( 'function_code' , '-1');
$storage_start_address =  JRequest::getVar( 'storage_start_address' , '-1');
$storage_numbers =  JRequest::getVar( 'storage_numbers' , '-1');
$check_code =  JRequest::getVar( 'check_code' , '-1');


/*$meter_factory = trim($_POST['meter_factory']); 
//if ($meter_model=="") {echo "meter_model==()";} 
$command_code =trim($_POST['command_code']);
$var_len = trim($_POST['var_len']);
$address_code =trim($_POST['address_code']);
$function_code = trim($_POST["function_code"]);
$storage_start_address =trim($_POST['storage_start_address']); 
$storage_numbers =trim($_POST['storage_numbers']);
$check_code = trim($_POST['check_code']);
//if ($check_code!="") {echo "check_code==".$check_code;} 
*/
date_default_timezone_set('Asia/Singapore');
$datetime = date('Y-m-d H:i:s');
$datetime_create = $datetime;


// insert to database
//ModDianBiaoHelper::insertMetermodelValues($datetime_create, $meter_model, $command_code, $var_len, $address_code, $function_code, $storage_start_address, $storage_numbers, $check_code);

    $sq = "select * from joomla3_metermodel where command_code = '$command_code' order by id desc";
	   $rst = mysql_query($sq);
       @$row = mysql_fetch_array($rst);
    if($row == true){
      mysql_close();
  
      echo " <script>alert('数据库中已存在相同的指令码！');history.back(); </script>";
  
    }else{
       $sql = "insert into joomla3_metermodel 
	     (meter_model, meter_factory, command_code, var_len, address_code, function_code, storage_start_address, storage_numbers, check_code, datetime_create)
	   values 
	     ('$meter_model', '$meter_factory', '$command_code', '$var_len', '$address_code', '$function_code', '$storage_start_address', '$storage_numbers','$check_code', '$datetime_create')";
	   
	   $result = mysql_query($sql);
	   
	   if($result==false){
         mysql_close();
         echo "<script>alert('写入数据表时出错！');history.back(); </script>";
       }else{
        
	       mysql_close();
           echo "<script>alert('录入成功！');history.back(); </script>";

       }
 
 	 mysql_close();  
	   
	}  
	   
	   
require(JModuleHelper::getLayoutPath('mod_meter_model_submit', 'default'));	   
?>