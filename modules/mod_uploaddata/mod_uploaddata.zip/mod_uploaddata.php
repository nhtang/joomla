﻿<?php
/**
 * @package     electromonitor.com
 * @subpackage  mod_uploaddata
 *
 * @copyright   Copyright (C) 2015 All rights reserved.
 */

defined('_JEXEC') or die;

// Include the functions only once
require_once __DIR__ . '/helper.php';
 
//JHTML::stylesheet('styles.css','modules/mod_updata/css/');

require(JModuleHelper::getLayoutPath('mod_uploaddata', 'default'));
